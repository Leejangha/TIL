d = [(0,1), (-1,0), (0,-1), (1,0)]

for t in range(int(input())):
    N = int(input())
    # 높이의 외각을 0으로 둘러쌈
    h = [[0]*(N+2) for _ in range(N+2)]
    for i in range(1, N+1):
        h[i][1:N+1] = list(map(int, input().split()))
    # 봉우리의 개수 초기화
    cnt = 0
    for x in range(1, N+1):
        for y in range(1, N+1):
            # (1,1) 부터 (N+1,N+1)가지 탐색
            high = h[x][y]
            # 봉우리일 경우 True
            is_high = True
            # 4방향 탐색
            for dx, dy in d:
                nx, ny = x + dx, y + dy
                # 탐색하는 곳의 높이가 4방향의 높이보다 하나라도 작을 경우 False
                if high <= h[nx][ny]:
                    is_high = False
            # 봉우리일 경우 cnt + 1
            if is_high:
                cnt += 1

    print(f'#{t+1} {cnt}')
