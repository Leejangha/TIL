# 괄호
brackets = ['(', ')', '{', '}']

for t in range(int(input())):
    math = input()
    stack = []
    # 계산 결과
    res = 0
    # 괄호 검사 결과
    is_True = True
    for char in math:
        if stack:
            # 닫는 소괄호인 경우
            if char == ')':
                # 여는 소괄호 까지 정수들을 더함
                while stack[-1] != '(':
                    # 여는 중괄호가 먼저 나올 경우 괄호 검사 결과는 실패이다
                    if stack[-1] == '{':
                        is_True = False
                        break
                    res += int(stack[-1])
                    stack.pop()
                stack.pop()
            # 닫는 중괄호인 경우
            elif char == '}':
                # 닫는 중괄호 까지 정수들을 곱함
                while stack[-1] != '{':
                    # 여는 소괄호가 먼저 나올 경우 괄호 검사 결과는 실패이다
                    if stack[-1] == '(':
                        is_True = False
                        break
                    res *= int(stack[-1])
                    stack.pop()
                stack.pop()
            # 여는 괄호나 정수인 경우
            else:
                stack.append(char)
        else:
            stack.append(char)
    # 스택에 값이 남아있거나 괄호 검사 결과가 실패인 경우
    if stack or not is_True:
        res = -1
    print(f'#{t+1} {res}')
